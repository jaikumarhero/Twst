
# Rainbow RAT
<img src="/Preview/RainbowRatMain.png" width="100%" />

#### This software is made for educational purposes only !

#### Main creator of Rainbow RAT is abyssal army (Luna)

Rainbow is a spyware based on Telegram bot for full access to Android devices.\
By using this tool, you can have full access to the target device and control all the actions of the device.


## Description

#### This tool is made of two parts, server and client.
**Server side:**\
The server implemented for this tool is built with the nodejs framework.

- Client management with socket IO
- Telegram bot management with telegram API

**Client side:**\
The client side of this tool is an application that must be installed on the target device.\
Client side of this tool is made with the Kotlin language and Jetpack Compose framework.\
This application consists of 5 main parts:
- Accessibility service
- Socket IO message handler
- Https file uploader
- Social engineering technique in welcome page to grant permissions by the user
- Responsive web view



## Features

**Initial accesses to the target device:**
- Access to contacts
- Access to incoming and outgoing SMS
- Access to notifications
- Access to call history
- Access to the list of installed applications
- Access to clipboard
- Display a short text message on the target device
- Vibrate target device with custom timing

<p float="left">
  <img src="/Preview/Frame 3.png" width="20%" />
  <img src="/Preview/Frame 4.png" width="20%" />
  <img src="/Preview/Frame 5.png" width="20%" />
  <img src="/Preview/Frame 6.png" width="20%" />
</p>

**Advanced access:**
- Access to the main camera and selfie camera
- Get a screenshot from the target device
- Send SMS with the target device
- Send SMS to all contacts saved on the target device
- Playing sound on the target device by sending voice in Telegram bot
- Record target device microphone with custom timing
- Access to all gallery images
- Display custom notification on target device

<p float="left">
  <img src="/Preview/Frame 7.png" width="20%" />
  <img src="/Preview/Frame 8.png" width="20%" />
  <img src="/Preview/Frame 9.png" width="20%" />
  <img src="/Preview/Frame 10.png" width="20%" />
</p>

**Advanced file explorer:**\
This tool gives you easy access to all the files of the target device, which can be easily managed through the buttons in the Telegram bot.
- Access to all files
- Delete files

<p float="left">
  <img src="/Preview/Frame 11.png" width="20%" />
  <img src="/Preview/Frame 12.png" width="20%" />
</p>

**Advanced Keylogger:**\
This tool reports to you all the actions performed on the target device such as:
- Texts typed in the device
- Notifications with details
- Opened applications
- Clicked buttons
- All the texts on the screen

<p float="left">
  <img src="/Preview/Frame 13.png" width="20%" />
  <img src="/Preview/Frame 14.png" width="20%" />
  <img src="/Preview/Frame 15.png" width="20%" />
  <img src="/Preview/Frame 16.png" width="20%" />
</p>

## How to use

**Setup server side**

modify data.json file that exist in server files and replace your own bot token and numric telegram ID

run nodejs server files on live host (like render.com)

**Setup client side**

copy your web service URL and modify connection.json that exist in assets folder and place your own URL(remember to put / at the end of the URL)

if you cant build app using source code just download apk file and modify it with apk editor

## Fallow me on social media
[![Telegram](https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/thisislunalight)
[![Twitter](https://img.shields.io/badge/Twitter-%231DA1F2.svg?style=for-the-badge&logo=Twitter&logoColor=white)](https://twitter.com/thisislunalight)
